import 'package:flutter/material.dart';
import 'package:newsapp/pages/data.dart';

void main() => runApp(const MaterialApp(
  debugShowCheckedModeBanner: false,
      home: NewsApp(),

    ));
 